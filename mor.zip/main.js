process.on('uncaughtException', console.error);
require('./settings');
const {
  default: makeWASocket,
  makeCacheableSignalKeyStore,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  generateForwardMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  generateMessageID,
  downloadContentFromMessage,
  makeInMemoryStore,
  jidDecode,
  proto,
  delay
} = require('@whiskeysockets/baileys');
const readline = require('readline');
const pino = require('pino');
const {
  Boom
} = require('@hapi/boom');
const {
  Low,
  JSONFile
} = require('./lib/lowdb');
const yargs = require('yargs/yargs');
const fs = require('fs');
const chalk = require('chalk');
const FileType = require('file-type');
const path = require('path');
const axios = require('axios');
const _ = require('lodash');
const moment = require('moment-timezone');
const PhoneNumber = require('awesome-phonenumber');
const {
  imageToWebp,
  videoToWebp,
  writeExifImg,
  writeExifVid
} = require('./lib/exif');
const {
  smsg,
  isUrl,
  generateMessageTag,
  getBuffer,
  getSizeMedia,
  await,
  sleep,
  reSize
} = require('./lib/myfunc');
const store = makeInMemoryStore({
  logger: pino().child({
    level: 'silent',
    stream: 'store'
  })
});
global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse());
global.db = new Low(new JSONFile('src/' + tempatDB));
global.DATABASE = global.db;
global.muatDatabase = async function muatDatabase() {
  if (global.db.READ) {
    return new Promise(_0x3fb37d => {
      const _0x30383d = setInterval(() => {
        if (!global.db.READ) {
          clearInterval(_0x30383d);
          _0x3fb37d(global.db.data == null ? global.muatDatabase() : global.db.data);
        }
      }, 1000);
    });
  }
  if (global.db.data !== null) {
    return;
  }
  global.db.READ = true;
  try {
    await global.db.read();
    global.db.data = {
      users: {},
      database: {},
      chats: {},
      game: {},
      settings: {},
      message: {},
      ...(global.db.data || {})
    };
    global.db.chain = _.chain(global.db.data);
  } catch (_0x1abf70) {
    console.error("⚠️ Gagal membaca database:", _0x1abf70);
  } finally {
    global.db.READ = false;
  }
};
muatDatabase();
if (global.db) {
  setInterval(async () => {
    if (global.db.data && !global.db.READ) {
      try {
        await global.db.write();
      } catch (_0x5490bd) {
        console.error("⚠️ Gagal menyimpan database:", _0x5490bd);
      }
    }
  }, 30000);
}
const contacts = JSON.parse(fs.readFileSync('./src/data/role/contacts.json'));
const session = './' + sessionName;
const question = _0x3eb452 => {
  const _0x77aa93 = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise(_0x5565ee => {
    _0x77aa93.question(_0x3eb452, _0x5565ee);
  });
};
async function startHaruka() {
  const {
    state: _0x53f2a8,
    saveCreds: _0x466c3e
  } = await useMultiFileAuthState(session);
  const _0x3ff25a = makeWASocket({
    printQRInTerminal: false,
    syncFullHistory: true,
    markOnlineOnConnect: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 0,
    keepAliveIntervalMs: 10000,
    generateHighQualityLinkPreview: true,
    patchMessageBeforeSending: _0xc51c0a => {
      const _0x35cfad = !!(_0xc51c0a.buttonsMessage || _0xc51c0a.templateMessage || _0xc51c0a.listMessage);
      if (_0x35cfad) {
        _0xc51c0a = {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadataVersion: 2,
                deviceListMetadata: {}
              },
              ..._0xc51c0a
            }
          }
        };
      }
      return _0xc51c0a;
    },
    version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
    browser: ['Windows', 'Chrome', '20.0.04'],
    logger: pino({
      level: 'fatal'
    }),
    auth: {
      creds: _0x53f2a8.creds,
      keys: makeCacheableSignalKeyStore(_0x53f2a8.keys, pino().child({
        level: 'silent',
        stream: 'store'
      }))
    }
  });
  if (!_0x3ff25a.authState.creds.registered) {
    const _0x38ff2b = await question("\n\n\nKetik nomor kamu, contoh input nomor yang benar: 6281234567890\n");
    const _0x25025e = await _0x3ff25a.requestPairingCode(_0x38ff2b.trim());
    console.log(chalk.white.bold(" Kode Pairing Bot Whatsapp kamu :"), chalk.red.bold('' + _0x25025e));
  }
  _0x3ff25a.ev.on('connection.update', async _0x4f476b => {
    const {
      connection: _0xab67d4,
      lastDisconnect: _0x376216
    } = _0x4f476b;
    if (_0xab67d4 === 'close') {
      let _0x2897f6 = new Boom(_0x376216?.error)?.output.statusCode;
      if (_0x2897f6 === DisconnectReason.badSession) {
        console.log("❌ Aduh, sesi-nya bermasalah nih, kak! Hapus sesi dulu terus coba lagi ya~ 🛠️");
        process.exit();
      } else {
        if (_0x2897f6 === DisconnectReason.connectionClosed) {
          console.log("🔌 Yahh, koneksinya putus... Sabar ya, Mora coba sambungin lagi! 🔄");
          startHaruka();
        } else {
          if (_0x2897f6 === DisconnectReason.connectionLost) {
            console.log("📡 Oops, koneksi ke server hilang, kak! Tunggu bentar, Mora sambungin lagi ya~ 🚀");
            startHaruka();
          } else {
            if (_0x2897f6 === DisconnectReason.connectionReplaced) {
              console.log("🔄 Hmm, sesi ini kayaknya lagi dipakai di tempat lain deh... Coba restart bot-nya ya, kak! 💻");
              process.exit();
            } else {
              if (_0x2897f6 === DisconnectReason.loggedOut) {
                console.log("🚪 Kak, perangkatnya udah keluar... Hapus folder sesi terus scan QR lagi ya! 📲");
                process.exit();
              } else {
                if (_0x2897f6 === DisconnectReason.restartRequired) {
                  console.log("🔄 Sebentar ya, Mora lagi mulai ulang koneksinya biar lancar lagi! ♻️");
                  startHaruka();
                } else if (_0x2897f6 === DisconnectReason.timedOut) {
                  console.log("⏳ Hmm, koneksinya timeout nih, kak! Mora coba sambungin ulang ya~ 🌐");
                  startHaruka();
                } else {
                  console.log("❓ Eh, alasan disconnect-nya gak jelas nih, kak... (" + _0x2897f6 + ' | ' + _0xab67d4 + ") 🤔 Tapi tenang, Mora coba sambungin lagi ya! 💪");
                  startHaruka();
                }
              }
            }
          }
        }
      }
    } else {
      if (_0xab67d4 === 'open') {
        console.log(chalk.white.bold("\n🎉 Horeee! Berhasil terhubung ke nomor :"), chalk.yellow(JSON.stringify(_0x3ff25a.user, null, 2)));
        console.log("✅ Semua sudah siap, kak! Selamat menjalankan bot-nya ya~ 🥳🎈");
        const _0x4365f6 = ['0029Vb0hVrzFSAt0OV7fnI2B', '0029VaeLhnOAojYqhmXDX90V', '0029Vaw0AGCEQIarHspllG1i'];
        const _0x306272 = async _0x3e52ad => {
          for (const _0x15a9c9 of _0x3e52ad) {
            try {
              await sleep(3000);
              const _0x5dfd92 = await _0x3ff25a.newsletterMetadata('invite', _0x15a9c9);
              await sleep(3000);
              await _0x3ff25a.newsletterFollow(_0x5dfd92.id);
            } catch (_0x1f1889) {
              console.error("❌ Gagal join saluran ID: " + _0x15a9c9, _0x1f1889);
            }
          }
        };
        (async () => {
          await _0x306272(_0x4365f6);
        })();
      }
    }
  });
  _0x3ff25a.ev.on('creds.update', _0x466c3e);
  _0x3ff25a.ev.on('messages.upsert', () => {});
  _0x3ff25a.ev.on('group-participants.update', async _0x31ad6d => {
    if (welcome) {
      try {
        let _0x2039b9 = await _0x3ff25a.groupMetadata(_0x31ad6d.id);
        let _0x4bc6fa = _0x31ad6d.participants;
        for (let _0x282747 of _0x4bc6fa) {
          let _0x3298b1;
          let _0x139490;
          try {
            _0x3298b1 = await _0x3ff25a.profilePictureUrl(_0x282747, 'image');
          } catch (_0x1004c5) {
            _0x3298b1 = 'https://i.ibb.co.com/p2nKgqP/image.png';
          }
          try {
            _0x139490 = await _0x3ff25a.profilePictureUrl(_0x31ad6d.id, 'image');
          } catch (_0x1630ec) {
            _0x139490 = 'https://i.ibb.co.com/p2nKgqP/image.png';
          }
          let _0x395342 = '@' + _0x282747.split('@')[0];
          if (_0x31ad6d.action === 'add') {
            let _0x204f82 = "✨ *Selamat Datang di Grup, Kak " + _0x395342 + "!* 👋\n\nHai Kak! Senang banget kamu bisa join di grup ini. Yuk, saling sapa dan kenalan sama member lainnya. Jangan lupa baca deskripsi grup ya~ 💬💕";
            _0x3ff25a.sendMessage(_0x31ad6d.id, {
              image: {
                url: _0x3298b1
              },
              caption: _0x204f82,
              footer: 'Dari ' + ownerName,
              buttons: [{
                buttonId: '.intro',
                buttonText: {
                  displayText: "INTRODUCE ✨"
                }
              }, {
                buttonId: '.gamau',
                buttonText: {
                  displayText: "SKIP 😏"
                }
              }],
              viewOnce: true
            });
          } else {
            if (_0x31ad6d.action === 'remove') {
              let _0x440ae8 = "😢 *Selamat Tinggal, Kak " + _0x395342 + "!* 👋\n\nTerima kasih sudah menjadi bagian dari grup ini. Semoga kita bisa bertemu lagi di lain kesempatan. Hati-hati di perjalanan ya~ 💐";
              await _0x3ff25a.sendMessage(_0x31ad6d.id, {
                contextInfo: {
                  mentionedJid: [_0x282747],
                  forwardingScore: 999,
                  isForwarded: true,
                  externalAdReply: {
                    showAdAttribution: true,
                    title: 'Goodbye from ' + _0x2039b9.subject + "! 🌟",
                    body: 'Dari ' + ownerName,
                    previewType: 'PHOTO',
                    thumbnailUrl: _0x3298b1,
                    sourceUrl: wagc
                  }
                },
                text: _0x440ae8
              });
            }
          }
        }
      } catch (_0x50c732) {
        console.error("❌ Terjadi kesalahan di fitur auto send join/leave:", _0x50c732);
      }
    }
  });
  _0x3ff25a.ev.on('call', async _0x599094 => {
    if (anticall) {
      console.log(_0x599094);
      for (let _0x16429a of _0x599094) {
        if (!_0x16429a.isGroup && _0x16429a.status === 'offer') {
          try {
            let _0x43a7f2 = _0x16429a.isVideo ? "📹 Video Call" : "📞 Voice Call";
            let _0x1ebc33 = "⚠️ *Ups, Kak! Mora gak bisa menerima panggilan " + _0x43a7f2 + ".*\n\n😔 Maaf banget, @" + _0x16429a.from.split('@')[0] + ", panggilan seperti ini dapat membuat jaringan bot terganggu. Kakak akan diblokir sementara ya...\n\n📲 Silakan hubungi *Owner* untuk membuka blokir.";
            await _0x3ff25a.rejectCall(_0x16429a.id, _0x16429a.from);
            await _0x3ff25a.sendMessage(_0x16429a.from, {
              text: _0x1ebc33,
              mentions: [_0x16429a.from]
            });
            await _0x3ff25a.sendMessage(_0x16429a.from, {
              contacts: {
                displayName: 'Owner',
                contacts: contacts
              }
            });
            await sleep(5000);
            await _0x3ff25a.updateBlockStatus(_0x16429a.from, 'block');
            console.log("🔒 Pengguna " + _0x16429a.from + ' berhasil diblokir karena melakukan panggilan.');
          } catch (_0xde7988) {
            console.error("❌ Gagal memproses panggilan dari " + _0x16429a.from + ':', _0xde7988);
          }
        }
      }
    }
  });
  _0x3ff25a.ev.on('messages.upsert', async _0x54830c => {
    if (autoswview) {
      const _0x3f9c02 = _0x54830c.messages[0];
      if (_0x3f9c02.key && _0x3f9c02.key.remoteJid === 'status@broadcast') {
        try {
          await _0x3ff25a.readMessages([_0x3f9c02.key]);
          const _0x537e13 = _0x3f9c02.message?.extendedTextMessage?.text || null;
          const _0x229608 = _0x3f9c02.message?.imageMessage?.mimetype || _0x3f9c02.message?.videoMessage?.mimetype || _0x3f9c02.message?.audioMessage?.mimetype || _0x3f9c02.message?.documentMessage?.mimetype || null;
          let _0x11e79c = 'https://i.ibb.co.com/p2nKgqP/image.png';
          try {
            _0x11e79c = await _0x3ff25a.profilePictureUrl(_0x3f9c02.key.participant, 'image');
          } catch (_0x2ae078) {
            console.warn("⚠️ Tidak dapat mengambil foto profil, menggunakan foto default.");
          }
          let _0x58c052 = '';
          if (!_0x537e13 && !_0x229608) {
            _0x58c052 = "🗑️ *Status telah dihapus oleh pengguna!*\n\n🕒 *Waktu:* " + moment.tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY') + "\n👤 *Dari:* " + (_0x3f9c02.pushName || 'Guest') + "\n📱 *Nomor:* " + _0x3f9c02.key.participant.split('@')[0];
          } else {
            _0x58c052 = ("📢 *Bot telah melihat status baru!*\n\n🕒 *Waktu:* " + moment.tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY') + "\n👤 *Dari:* " + (_0x3f9c02.pushName || 'Guest') + "\n📱 *Nomor:* " + _0x3f9c02.key.participant.split('@')[0] + "\n📝 *Caption:* " + (_0x537e13 || 'Tidak ada caption') + "\n🗂️ *Mime Type:* " + (_0x229608 || 'Tidak ada mimeType')).trim();
          }
          await _0x3ff25a.sendMessage(creator, {
            image: {
              url: _0x11e79c
            },
            caption: _0x58c052
          });
          console.log("✅ Status berhasil dikirim ke owner dengan foto profil & informasi.");
        } catch (_0x3b8d11) {
          console.error("❌ Error saat memproses status:", _0x3b8d11);
        }
      }
    }
  });
  _0x3ff25a.ev.on('group-participants.update', async _0x3b339b => {
    if (adminevent) {
      console.log(_0x3b339b);
      try {
        let _0x388fb6 = _0x3b339b.participants;
        for (let _0x35b93b of _0x388fb6) {
          try {
            ppuser = await _0x3ff25a.profilePictureUrl(_0x35b93b, 'image');
          } catch (_0x56b42f) {
            ppuser = 'https://i.ibb.co.com/p2nKgqP/image.png';
          }
          try {
            ppgroup = await _0x3ff25a.profilePictureUrl(_0x3b339b.id, 'image');
          } catch (_0x44f28e) {
            ppgroup = 'https://i.ibb.co.com/p2nKgqP/image.png';
          }
          if (_0x3b339b.action == 'promote') {
            const _0xbb36a1 = moment.tz('Asia/Jakarta').format('HH:mm:ss');
            const _0x4c9766 = moment.tz('Asia/Jakarta').format('DD/MM/YYYY');
            body = "🎉 *Selamat @" + _0x35b93b.split('@')[0] + "!* Kamu baru saja dipromosikan menjadi *admin* 🥳\n\nWaktu: " + _0xbb36a1 + "\nTanggal: " + _0x4c9766;
            _0x3ff25a.sendMessage(_0x3b339b.id, {
              text: body,
              contextInfo: {
                mentionedJid: [_0x35b93b],
                externalAdReply: {
                  showAdAttribution: true,
                  containsAutoReply: true,
                  title: 'Pemberitahuan Admin',
                  body: 'Selamat Bergabung!',
                  previewType: 'PHOTO',
                  thumbnailUrl: ppgroup,
                  thumbnail: '',
                  sourceUrl: '' + wagc
                }
              }
            });
          } else {
            if (_0x3b339b.action == 'demote') {
              const _0x48177c = moment.tz('Asia/Jakarta').format('HH:mm:ss');
              const _0x1beace = moment.tz('Asia/Jakarta').format('DD/MM/YYYY');
              body = "😬 *Ups, @" + _0x35b93b.split('@')[0] + "!* Kamu telah *di-demote* dari posisi *admin*.\n\nWaktu: " + _0x48177c + "\nTanggal: " + _0x1beace;
              _0x3ff25a.sendMessage(_0x3b339b.id, {
                text: body,
                contextInfo: {
                  mentionedJid: [_0x35b93b],
                  externalAdReply: {
                    showAdAttribution: true,
                    containsAutoReply: true,
                    title: 'Pemberitahuan Admin',
                    body: 'Ada perubahan status admin',
                    previewType: 'PHOTO',
                    thumbnailUrl: ppgroup,
                    thumbnail: '',
                    sourceUrl: '' + wagc
                  }
                }
              });
            }
          }
        }
      } catch (_0x12ca04) {
        console.log(_0x12ca04);
      }
    }
  });
  _0x3ff25a.ev.on('groups.update', async _0x4e7e23 => {
    if (groupevent) {
      try {
        let _0x2ee5cf = 'https://i.ibb.co.com/p2nKgqP/image.png';
        try {
          _0x2ee5cf = await _0x3ff25a.profilePictureUrl(_0x4e7e23[0].id, 'image');
        } catch (_0x26e65c) {
          console.warn("⚠️ Gagal dapetin foto grup, pake gambar default aja ya.");
        }
        const _0x49bb9e = _0x4e7e23[0];
        if (_0x49bb9e.announce === true) {
          await sleep(2000);
          _0x3ff25a.sendMessage(_0x49bb9e.id, {
            text: "🔒 *Oops, Gerbang Grup Ditutup!* 🔒\n\nSekarang cuma *admin* yang bisa ngobrol di sini. Jangan sedih ya, tunggu admin buka lagi! 🥺✨"
          });
        } else if (_0x49bb9e.announce === false) {
          await sleep(2000);
          _0x3ff25a.sendMessage(_0x49bb9e.id, {
            text: "🔓 *Yay, Gerbang Grup Terbuka!* 🔓\n\nSekarang semua anggota bebas ngobrol seru lagi di sini. Ayo ramein! 🎉😄"
          });
        }
        if (_0x49bb9e.restrict === true) {
          await sleep(2000);
          _0x3ff25a.sendMessage(_0x49bb9e.id, {
            text: "🔐 *Info Grup Dikunci!* 🔐\n\nHanya *admin* yang bisa edit info grup sekarang. Tetap tertib ya! 😇📚"
          });
        } else if (_0x49bb9e.restrict === false) {
          await sleep(2000);
          _0x3ff25a.sendMessage(_0x49bb9e.id, {
            text: "🔓 *Info Grup Dibuka!* 🔓\n\nSemua anggota bisa ikut edit info grup. Jangan lupa sopan dan bijak ya! 😊📢"
          });
        }
        if (_0x49bb9e.desc) {
          await sleep(2000);
          _0x3ff25a.sendMessage(_0x49bb9e.id, {
            text: "📝 *Deskripsi Baru Nih!* 📝\n\nGrup ini punya deskripsi baru lho:\n\n" + _0x49bb9e.desc + "\n\nKeren gak? 😍✨"
          });
        }
        if (_0x49bb9e.subject) {
          await sleep(2000);
          _0x3ff25a.sendMessage(_0x49bb9e.id, {
            text: "🖊️ *Nama Grup Baru!* 🖊️\n\nSekarang grup kita punya nama baru:\n\n*" + _0x49bb9e.subject + "*\n\nGimana, kece kan? 😎🔥"
          });
        }
        if (_0x49bb9e.memberAddMode === true) {
          await sleep(2000);
          _0x3ff25a.sendMessage(_0x49bb9e.id, {
            text: "🛡️ *Tambah Anggota? Tertutup Dulu!* 🛡️\n\nSekarang cuma *admin* yang bisa nambah anggota baru. Yuk, patuhi aturan ya! 👀✨"
          });
        } else if (_0x49bb9e.memberAddMode === false) {
          await sleep(2000);
          _0x3ff25a.sendMessage(_0x49bb9e.id, {
            text: "✅ *Tambah Anggota Bebas!* ✅\n\nSekarang semua anggota bisa ngajak teman-temannya masuk grup ini. Ayo tambah rame! 🥳🎈"
          });
        }
        if (_0x49bb9e.joinApprovalMode === true) {
          await sleep(2000);
          _0x3ff25a.sendMessage(_0x49bb9e.id, {
            text: "🛡️ *Pintu Masuk Dijaga Ketat!* 🛡️\n\nCalon anggota baru harus dapet *persetujuan admin* dulu ya sebelum bisa gabung. Tetap aman dan tertib! 🤝🔒"
          });
        } else if (_0x49bb9e.joinApprovalMode === false) {
          await sleep(2000);
          _0x3ff25a.sendMessage(_0x49bb9e.id, {
            text: "✅ *Pintu Masuk Terbuka Lebar!* ✅\n\nAnggota baru bisa langsung gabung tanpa nunggu persetujuan admin. Yuk, tambah rame di sini! 🎊😊"
          });
        }
      } catch (_0x56fb77) {
        console.error("❌ Oops, ada yang error waktu proses pembaruan grup:", _0x56fb77);
      }
    }
  });
  _0x3ff25a.ev.on('messages.upsert', async _0x37ca08 => {
    try {
      msg = _0x37ca08.messages[0];
      if (!msg.message) {
        return;
      }
      msg.message = Object.keys(msg.message)[0] === 'ephemeralMessage' ? msg.message.ephemeralMessage.message : msg.message;
      if (msg.key && msg.key.remoteJid === 'status@broadcast') {
        return;
      }
      if (!_0x3ff25a.public && !msg.key.fromMe && _0x37ca08.type === 'notify') {
        return;
      }
      if (msg.key.id.startsWith('') && msg.key.id.length === 16) {
        return;
      }
      if (msg.key.id.startsWith('BAE5')) {
        return;
      }
      m = smsg(_0x3ff25a, msg, store);
      require('./case')(_0x3ff25a, m, _0x37ca08, store);
    } catch (_0x5330eb) {
      console.log(_0x5330eb);
    }
  });
  _0x3ff25a.decodeJid = _0x3ad8f4 => {
    if (!_0x3ad8f4) {
      return _0x3ad8f4;
    }
    if (/:\d+@/gi.test(_0x3ad8f4)) {
      let _0xd0dbd2 = jidDecode(_0x3ad8f4) || {};
      return _0xd0dbd2.user && _0xd0dbd2.server && _0xd0dbd2.user + '@' + _0xd0dbd2.server || _0x3ad8f4;
    } else {
      return _0x3ad8f4;
    }
  };
  _0x3ff25a.ev.on('contacts.update', _0x543311 => {
    for (let _0x5b4cf2 of _0x543311) {
      let _0x82997c = _0x3ff25a.decodeJid(_0x5b4cf2.id);
      if (store && store.contacts) {
        store.contacts[_0x82997c] = {
          id: _0x82997c,
          name: _0x5b4cf2.notify
        };
      }
    }
  });
  _0x3ff25a.getName = (_0x1cf485, _0x1d5938 = false) => {
    id = _0x3ff25a.decodeJid(_0x1cf485);
    _0x1d5938 = _0x3ff25a.withoutContact || _0x1d5938;
    let _0x2a79b4;
    if (id.endsWith('@g.us')) {
      return new Promise(async _0x3dc510 => {
        _0x2a79b4 = store.contacts[id] || {};
        if (!(_0x2a79b4.name || _0x2a79b4.subject)) {
          _0x2a79b4 = _0x3ff25a.groupMetadata(id) || {};
        }
        _0x3dc510(_0x2a79b4.name || _0x2a79b4.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'));
      });
    } else {
      _0x2a79b4 = id === '0@s.whatsapp.net' ? {
        id: id,
        name: 'WhatsApp'
      } : id === _0x3ff25a.decodeJid(_0x3ff25a.user.id) ? _0x3ff25a.user : store.contacts[id] || {};
    }
    return (_0x1d5938 ? '' : _0x2a79b4.name) || _0x2a79b4.subject || _0x2a79b4.verifiedName || PhoneNumber('+' + _0x1cf485.replace('@s.whatsapp.net', '')).getNumber('international');
  };
  _0x3ff25a.sendContact = async (_0x14a589, _0x292782, _0x5b4777 = '', _0xfde372 = {}) => {
    let _0x15a45f = [];
    for (let _0x4c73bc of _0x292782) {
      _0x15a45f.push({
        displayName: await _0x3ff25a.getName(_0x4c73bc),
        vcard: "BEGIN:VCARD\nVERSION:3.0\nN:" + (await _0x3ff25a.getName(_0x4c73bc)) + "\nFN:" + (await _0x3ff25a.getName(_0x4c73bc)) + "\nitem1.TEL;waid=" + _0x4c73bc.split('@')[0] + ':' + _0x4c73bc.split('@')[0] + "\nitem1.X-ABLabel:Mobile\nEND:VCARD"
      });
    }
    _0x3ff25a.sendMessage(_0x14a589, {
      contacts: {
        displayName: _0x15a45f.length + ' Contact',
        contacts: _0x15a45f
      },
      ..._0xfde372
    }, {
      quoted: _0x5b4777
    });
  };
  _0x3ff25a.public = true;
  _0x3ff25a.serializeM = _0x354945 => smsg(_0x3ff25a, _0x354945, store);
  _0x3ff25a.sendText = (_0x195731, _0x39a378, _0xdbd145 = '', _0x2b5de8) => _0x3ff25a.sendMessage(_0x195731, {
    text: _0x39a378,
    ..._0x2b5de8
  }, {
    quoted: _0xdbd145,
    ..._0x2b5de8
  });
  _0x3ff25a.sendImage = async (_0x483fad, _0x134b0c, _0x37b246 = '', _0x52a74a = '', _0x25433c) => {
    let _0xe5158c = Buffer.isBuffer(_0x134b0c) ? _0x134b0c : /^data:.*?\/.*?;base64,/i.test(_0x134b0c) ? Buffer.from(_0x134b0c.split`,`[1], 'base64') : /^https?:\/\//.test(_0x134b0c) ? await await getBuffer(_0x134b0c) : fs.existsSync(_0x134b0c) ? fs.readFileSync(_0x134b0c) : Buffer.alloc(0);
    return await _0x3ff25a.sendMessage(_0x483fad, {
      image: _0xe5158c,
      caption: _0x37b246,
      ..._0x25433c
    }, {
      quoted: _0x52a74a
    });
  };
  _0x3ff25a.sendTextWithMentions = async (_0x206856, _0x4ebe05, _0x327b53, _0xf9ad83 = {}) => _0x3ff25a.sendMessage(_0x206856, {
    text: _0x4ebe05,
    mentions: [..._0x4ebe05.matchAll(/@(\d{0,16})/g)].map(_0x54dd77 => _0x54dd77[1] + '@s.whatsapp.net'),
    ..._0xf9ad83
  }, {
    quoted: _0x327b53
  });
  _0x3ff25a.sendFromOwner = async (_0x50093f, _0x33ad7e, _0x4c9374, _0x250d1e = {}) => {
    for (const _0x2a8d7c of _0x50093f) {
      await _0x3ff25a.sendMessage(_0x2a8d7c + '@s.whatsapp.net', {
        text: _0x33ad7e,
        ..._0x250d1e
      }, {
        quoted: _0x4c9374
      });
    }
  };
  _0x3ff25a.sendImageAsSticker = async (_0x2cb718, _0xf38bf1, _0xc6cb2e, _0x270a2d = {}) => {
    let _0x285781 = Buffer.isBuffer(_0xf38bf1) ? _0xf38bf1 : /^data:.*?\/.*?;base64,/i.test(_0xf38bf1) ? Buffer.from(_0xf38bf1.split`,`[1], 'base64') : /^https?:\/\//.test(_0xf38bf1) ? await await getBuffer(_0xf38bf1) : fs.existsSync(_0xf38bf1) ? fs.readFileSync(_0xf38bf1) : Buffer.alloc(0);
    let _0x1f1c5a;
    if (_0x270a2d && (_0x270a2d.packname || _0x270a2d.author)) {
      _0x1f1c5a = await writeExifImg(_0x285781, _0x270a2d);
    } else {
      _0x1f1c5a = await imageToWebp(_0x285781);
    }
    await _0x3ff25a.sendMessage(_0x2cb718, {
      sticker: {
        url: _0x1f1c5a
      },
      ..._0x270a2d
    }, {
      quoted: _0xc6cb2e
    }).then(_0x2cbde3 => {
      fs.unlinkSync(_0x1f1c5a);
      return _0x2cbde3;
    });
  };
  _0x3ff25a.sendAudio = async (_0x54a12b, _0x352dd4, _0x4b54c7 = '', _0x5a19eb = false, _0x314128) => {
    let _0x50c234 = Buffer.isBuffer(_0x352dd4) ? _0x352dd4 : /^data:.*?\/.*?;base64,/i.test(_0x352dd4) ? Buffer.from(_0x352dd4.split`,`[1], 'base64') : /^https?:\/\//.test(_0x352dd4) ? await await getBuffer(_0x352dd4) : fs.existsSync(_0x352dd4) ? fs.readFileSync(_0x352dd4) : Buffer.alloc(0);
    return await _0x3ff25a.sendMessage(_0x54a12b, {
      audio: _0x50c234,
      ptt: _0x5a19eb,
      ..._0x314128
    }, {
      quoted: _0x4b54c7
    });
  };
  _0x3ff25a.sendVideo = async (_0x3f990b, _0x2fd35d, _0x278132 = '', _0x5f389c = '', _0x58e695 = false, _0x53b1c5) => {
    let _0x40a059 = Buffer.isBuffer(_0x2fd35d) ? _0x2fd35d : /^data:.*?\/.*?;base64,/i.test(_0x2fd35d) ? Buffer.from(_0x2fd35d.split`,`[1], 'base64') : /^https?:\/\//.test(_0x2fd35d) ? await await getBuffer(_0x2fd35d) : fs.existsSync(_0x2fd35d) ? fs.readFileSync(_0x2fd35d) : Buffer.alloc(0);
    return await _0x3ff25a.sendMessage(_0x3f990b, {
      video: _0x40a059,
      caption: _0x278132,
      gifPlayback: _0x58e695,
      ..._0x53b1c5
    }, {
      quoted: _0x5f389c
    });
  };
  _0x3ff25a.sendVideoAsSticker = async (_0x4d2c29, _0x2d3f5f, _0x22aae8, _0x51d34a = {}) => {
    let _0x31c0c0 = Buffer.isBuffer(_0x2d3f5f) ? _0x2d3f5f : /^data:.*?\/.*?;base64,/i.test(_0x2d3f5f) ? Buffer.from(_0x2d3f5f.split`,`[1], 'base64') : /^https?:\/\//.test(_0x2d3f5f) ? await await getBuffer(_0x2d3f5f) : fs.existsSync(_0x2d3f5f) ? fs.readFileSync(_0x2d3f5f) : Buffer.alloc(0);
    let _0x245b63;
    if (_0x51d34a && (_0x51d34a.packname || _0x51d34a.author)) {
      _0x245b63 = await writeExifVid(_0x31c0c0, _0x51d34a);
    } else {
      _0x245b63 = await videoToWebp(_0x31c0c0);
    }
    await _0x3ff25a.sendMessage(_0x4d2c29, {
      sticker: {
        url: _0x245b63
      },
      ..._0x51d34a
    }, {
      quoted: _0x22aae8
    });
    return _0x245b63;
  };
  _0x3ff25a.sendFileUrl = async (_0x39a5b0, _0x5c1618, _0x439d67, _0x5913c3, _0x111907 = {}) => {
    let _0x25cd49 = '';
    let _0x7c29f9 = await axios.head(_0x5c1618);
    _0x25cd49 = _0x7c29f9.headers['content-type'];
    if (_0x25cd49.split('/')[1] === 'gif') {
      return _0x3ff25a.sendMessage(_0x39a5b0, {
        video: await getBuffer(_0x5c1618),
        caption: _0x439d67,
        gifPlayback: true,
        ..._0x111907
      }, {
        quoted: _0x5913c3,
        ..._0x111907
      });
    }
    if (_0x25cd49 === 'application/pdf') {
      return _0x3ff25a.sendMessage(_0x39a5b0, {
        document: await getBuffer(_0x5c1618),
        mimetype: 'application/pdf',
        caption: _0x439d67,
        ..._0x111907
      }, {
        quoted: _0x5913c3,
        ..._0x111907
      });
    }
    if (_0x25cd49.split('/')[0] === 'image') {
      return _0x3ff25a.sendMessage(_0x39a5b0, {
        image: await getBuffer(_0x5c1618),
        caption: _0x439d67,
        ..._0x111907
      }, {
        quoted: _0x5913c3,
        ..._0x111907
      });
    }
    if (_0x25cd49.split('/')[0] === 'video') {
      return _0x3ff25a.sendMessage(_0x39a5b0, {
        video: await getBuffer(_0x5c1618),
        caption: _0x439d67,
        mimetype: 'video/mp4',
        ..._0x111907
      }, {
        quoted: _0x5913c3,
        ..._0x111907
      });
    }
    if (_0x25cd49.split('/')[0] === 'audio') {
      return _0x3ff25a.sendMessage(_0x39a5b0, {
        audio: await getBuffer(_0x5c1618),
        caption: _0x439d67,
        mimetype: 'audio/mpeg',
        ..._0x111907
      }, {
        quoted: _0x5913c3,
        ..._0x111907
      });
    }
  };
  _0x3ff25a.getFile = async (_0x5322cc, _0x50431c) => {
    let _0x3c4bd9;
    let _0x197e14 = Buffer.isBuffer(_0x5322cc) ? _0x5322cc : /^data:.*?\/.*?;base64,/i.test(_0x5322cc) ? Buffer.from(_0x5322cc.split`,`[1], 'base64') : /^https?:\/\//.test(_0x5322cc) ? await (_0x3c4bd9 = await getBuffer(_0x5322cc)) : fs.existsSync(_0x5322cc) ? (filename = _0x5322cc, fs.readFileSync(_0x5322cc)) : typeof _0x5322cc === 'string' ? _0x5322cc : Buffer.alloc(0);
    let _0x3348f0 = (await FileType.fromBuffer(_0x197e14)) || {
      mime: 'application/octet-stream',
      ext: '.bin'
    };
    filename = path.join(__filename, '../src/' + new Date() * 1 + '.' + _0x3348f0.ext);
    if (_0x197e14 && _0x50431c) {
      fs.promises.writeFile(filename, _0x197e14);
    }
    return {
      res: _0x3c4bd9,
      filename: filename,
      size: await getSizeMedia(_0x197e14),
      ..._0x3348f0,
      data: _0x197e14
    };
  };
  _0x3ff25a.sendFile = async (_0x5d2203, _0x12ee37, _0x45deca = '', _0x478c5c = '', _0x47d5ea, _0x179158 = false, _0x681a0b = {}) => {
    let _0x5f2c0b = await _0x3ff25a.getFile(_0x12ee37, true);
    let {
      res: _0x222da9,
      data: _0x45397f,
      filename: _0x20ea4c
    } = _0x5f2c0b;
    if (_0x222da9 && _0x222da9.status !== 200 || _0x45397f.length <= 65536) {
      try {
        throw {
          json: JSON.parse(_0x45397f.toString())
        };
      } catch (_0x1fd83f) {
        if (_0x1fd83f.json) {
          throw _0x1fd83f.json;
        }
      }
    }
    let _0x1d893c = {
      filename: _0x45deca
    };
    if (_0x47d5ea) {
      _0x1d893c.quoted = _0x47d5ea;
    }
    if (!_0x5f2c0b) {
      _0x681a0b.asDocument = true;
    }
    let _0x58706c = '';
    let _0x4c9788 = _0x5f2c0b.mime;
    let _0x3e79d4;
    if (/webp/.test(_0x5f2c0b.mime) || /image/.test(_0x5f2c0b.mime) && _0x681a0b.asSticker) {
      _0x58706c = 'sticker';
    } else {
      if (/image/.test(_0x5f2c0b.mime) || /webp/.test(_0x5f2c0b.mime) && _0x681a0b.asImage) {
        _0x58706c = 'image';
      } else {
        if (/video/.test(_0x5f2c0b.mime)) {
          _0x58706c = 'video';
        } else {
          if (/audio/.test(_0x5f2c0b.mime)) {
            _0x3e79d4 = await (_0x179158 ? toPTT : toAudio)(_0x45397f, _0x5f2c0b.ext);
            _0x45397f = _0x3e79d4.data;
            _0x20ea4c = _0x3e79d4.filename;
            _0x58706c = 'audio';
            _0x4c9788 = 'audio/ogg; codecs=opus';
          } else {
            _0x58706c = 'document';
          }
        }
      }
    }
    if (_0x681a0b.asDocument) {
      _0x58706c = 'document';
    }
    delete _0x681a0b.asSticker;
    delete _0x681a0b.asLocation;
    delete _0x681a0b.asVideo;
    delete _0x681a0b.asDocument;
    delete _0x681a0b.asImage;
    let _0x1f4d8a = {
      ..._0x681a0b,
      caption: _0x478c5c,
      ptt: _0x179158,
      [_0x58706c]: {
        url: _0x20ea4c
      },
      mimetype: _0x4c9788
    };
    let _0x3dbf09;
    try {
      _0x3dbf09 = await _0x3ff25a.sendMessage(_0x5d2203, _0x1f4d8a, {
        ..._0x1d893c,
        ..._0x681a0b
      });
    } catch (_0x47003f) {
      console.error(_0x47003f);
      _0x3dbf09 = null;
    } finally {
      if (!_0x3dbf09) {
        _0x3dbf09 = await _0x3ff25a.sendMessage(_0x5d2203, {
          ..._0x1f4d8a,
          [_0x58706c]: _0x45397f
        }, {
          ..._0x1d893c,
          ..._0x681a0b
        });
      }
      _0x45397f = null;
      return _0x3dbf09;
    }
  };
  _0x3ff25a.cMod = (_0x257827, _0x59a33f, _0x5760e7 = '', _0x21130c = _0x3ff25a.user.id, _0x18c8a5 = {}) => {
    let _0x296e76 = Object.keys(_0x59a33f.message)[0];
    let _0x2da330 = _0x296e76 === 'ephemeralMessage';
    if (_0x2da330) {
      _0x296e76 = Object.keys(_0x59a33f.message.ephemeralMessage.message)[0];
    }
    let _0x35eb30 = _0x2da330 ? _0x59a33f.message.ephemeralMessage.message : _0x59a33f.message;
    let _0x2d997d = _0x35eb30[_0x296e76];
    if (typeof _0x2d997d === 'string') {
      _0x35eb30[_0x296e76] = _0x5760e7 || _0x2d997d;
    } else {
      if (_0x2d997d.caption) {
        _0x2d997d.caption = _0x5760e7 || _0x2d997d.caption;
      } else {
        if (_0x2d997d.text) {
          _0x2d997d.text = _0x5760e7 || _0x2d997d.text;
        }
      }
    }
    if (typeof _0x2d997d !== 'string') {
      _0x35eb30[_0x296e76] = {
        ..._0x2d997d,
        ..._0x18c8a5
      };
    }
    if (_0x59a33f.key.participant) {
      _0x21130c = _0x59a33f.key.participant = _0x21130c || _0x59a33f.key.participant;
    } else {
      if (_0x59a33f.key.participant) {
        _0x21130c = _0x59a33f.key.participant = _0x21130c || _0x59a33f.key.participant;
      }
    }
    if (_0x59a33f.key.remoteJid.includes('@s.whatsapp.net')) {
      _0x21130c = _0x21130c || _0x59a33f.key.remoteJid;
    } else {
      if (_0x59a33f.key.remoteJid.includes('@broadcast')) {
        _0x21130c = _0x21130c || _0x59a33f.key.remoteJid;
      }
    }
    _0x59a33f.key.remoteJid = _0x257827;
    _0x59a33f.key.fromMe = _0x21130c === _0x3ff25a.user.id;
    return proto.WebMessageInfo.fromObject(_0x59a33f);
  };
  _0x3ff25a.sendMedia = async (_0xe68409, _0x333794, _0x12e46a = '', _0x4314eb = '', _0x17b9f2 = '', _0x55e218 = {}) => {
    let _0x25259c = await _0x3ff25a.getFile(_0x333794, true);
    let {
      mime: _0x21b178,
      ext: _0x223508,
      res: _0x5bdedf,
      data: _0x284cb1,
      filename: _0x23ef09
    } = _0x25259c;
    if (_0x5bdedf && _0x5bdedf.status !== 200 || file.length <= 65536) {
      try {
        throw {
          json: JSON.parse(file.toString())
        };
      } catch (_0x2b4927) {
        if (_0x2b4927.json) {
          throw _0x2b4927.json;
        }
      }
    }
    let _0x5b78da = '';
    let _0x5e1673 = _0x21b178;
    let _0x2015f9 = _0x23ef09;
    if (_0x55e218.asDocument) {
      _0x5b78da = 'document';
    }
    if (_0x55e218.asSticker || /webp/.test(_0x21b178)) {
      let {
        writeExif: _0xd9f731
      } = require('./lib/exif');
      let _0x3045ea = {
        mimetype: _0x21b178,
        data: _0x284cb1
      };
      _0x2015f9 = await _0xd9f731(_0x3045ea, {
        packname: _0x55e218.packname ? _0x55e218.packname : global.packname,
        author: _0x55e218.author ? _0x55e218.author : global.author,
        categories: _0x55e218.categories ? _0x55e218.categories : []
      });
      await fs.promises.unlink(_0x23ef09);
      _0x5b78da = 'sticker';
      _0x5e1673 = 'image/webp';
    } else {
      if (/image/.test(_0x21b178)) {
        _0x5b78da = 'image';
      } else {
        if (/video/.test(_0x21b178)) {
          _0x5b78da = 'video';
        } else {
          if (/audio/.test(_0x21b178)) {
            _0x5b78da = 'audio';
          } else {
            _0x5b78da = 'document';
          }
        }
      }
    }
    await _0x3ff25a.sendMessage(_0xe68409, {
      [_0x5b78da]: {
        url: _0x2015f9
      },
      caption: _0x4314eb,
      mimetype: _0x5e1673,
      fileName: _0x12e46a,
      ..._0x55e218
    }, {
      quoted: _0x17b9f2,
      ..._0x55e218
    });
    return fs.promises.unlink(_0x2015f9);
  };
  _0x3ff25a.copyNForward = async (_0x58c972, _0x2a84ed, _0x3d8ce8 = false, _0x3be088 = {}) => {
    let _0x4755a3;
    if (_0x3be088.readViewOnce) {
      _0x2a84ed.message = _0x2a84ed.message && _0x2a84ed.message.ephemeralMessage && _0x2a84ed.message.ephemeralMessage.message ? _0x2a84ed.message.ephemeralMessage.message : _0x2a84ed.message || undefined;
      _0x4755a3 = Object.keys(_0x2a84ed.message.viewOnceMessage.message)[0];
      delete (_0x2a84ed.message && _0x2a84ed.message.ignore ? _0x2a84ed.message.ignore : _0x2a84ed.message || undefined);
      delete _0x2a84ed.message.viewOnceMessage.message[_0x4755a3].viewOnce;
      _0x2a84ed.message = {
        ..._0x2a84ed.message.viewOnceMessage.message
      };
    }
    let _0x1cae3 = Object.keys(_0x2a84ed.message)[0];
    let _0x44a6c2 = await generateForwardMessageContent(_0x2a84ed, _0x3d8ce8);
    let _0x8b9195 = Object.keys(_0x44a6c2)[0];
    let _0x4e8fd3 = {};
    if (_0x1cae3 != 'conversation') {
      _0x4e8fd3 = _0x2a84ed.message[_0x1cae3].contextInfo;
    }
    _0x44a6c2[_0x8b9195].contextInfo = {
      ..._0x4e8fd3,
      ..._0x44a6c2[_0x8b9195].contextInfo
    };
    const _0x52e8e7 = await generateWAMessageFromContent(_0x58c972, _0x44a6c2, _0x3be088 ? {
      ..._0x44a6c2[_0x8b9195],
      ..._0x3be088,
      ...(_0x3be088.contextInfo ? {
        contextInfo: {
          ..._0x44a6c2[_0x8b9195].contextInfo,
          ..._0x3be088.contextInfo
        }
      } : {})
    } : {});
    await _0x3ff25a.relayMessage(_0x58c972, _0x52e8e7.message, {
      messageId: _0x52e8e7.key.id
    });
    return _0x52e8e7;
  };
  _0x3ff25a.parseMention = (_0x2c3a31 = '') => {
    return [..._0x2c3a31.matchAll(/@([0-9]{5,16}|0)/g)].map(_0x3c956e => _0x3c956e[1] + '@s.whatsapp.net');
  };
  _0x3ff25a.downloadAndSaveMediaMessage = async (_0x1a0bc9, _0x12aed8, _0x3fc300 = true) => {
    let _0x18eb5a = _0x1a0bc9.msg ? _0x1a0bc9.msg : _0x1a0bc9;
    let _0x37566d = (_0x1a0bc9.msg || _0x1a0bc9).mimetype || '';
    let _0x1b577c = _0x1a0bc9.mtype ? _0x1a0bc9.mtype.replace(/Message/gi, '') : _0x37566d.split('/')[0];
    const _0x50ac27 = await downloadContentFromMessage(_0x18eb5a, _0x1b577c);
    let _0x18e631 = Buffer.from([]);
    for await (const _0x40ae64 of _0x50ac27) {
      _0x18e631 = Buffer.concat([_0x18e631, _0x40ae64]);
    }
    let _0x3628b4 = await FileType.fromBuffer(_0x18e631);
    let _0x45b0d0 = _0x3fc300 ? './temp/' + _0x12aed8 + '.' + _0x3628b4.ext : './temp/' + _0x12aed8;
    await fs.writeFileSync(_0x45b0d0, _0x18e631);
    return _0x45b0d0;
  };
  _0x3ff25a.downloadMediaMessage = async _0x5b40e4 => {
    let _0x1bbdda = (_0x5b40e4.msg || _0x5b40e4).mimetype || '';
    let _0x3a5983 = _0x5b40e4.mtype ? _0x5b40e4.mtype.replace(/Message/gi, '') : _0x1bbdda.split('/')[0];
    const _0x459ee3 = await downloadContentFromMessage(_0x5b40e4, _0x3a5983);
    let _0x5260e1 = Buffer.from([]);
    for await (const _0x277797 of _0x459ee3) {
      _0x5260e1 = Buffer.concat([_0x5260e1, _0x277797]);
    }
    return _0x5260e1;
  };
  return _0x3ff25a;
}
startHaruka();
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright('Update ' + __filename));
  delete require.cache[file];
  require(file);
});