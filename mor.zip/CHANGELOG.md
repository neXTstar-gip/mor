Update Terbaru MoraAI-v3.1.1

 お ─· Fix Fitur Get/Fetch Url Anti Penyusup
 お ─· Welcome with Button
 お ─· No Encrypt 99%
 お ─· Brat Fix
 お ─· AI Chat Freature Fix
 お ─· Cpanel Use Button
 お ─· Fix Bug
 お ─· Does not depend on the Rest API
 お ─· Using Scraper Directly Without Requesting to rest API first

NOTE: Dilarang keras share script!
Hargai creator, dan uang lu!

Script oleh (wa.me/6285655548594)
Base oleh ZeeoneOfc (Haruka-Md)
